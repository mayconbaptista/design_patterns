package factory;

import java.util.*;

public class Main {
	public static void main (String [] args) {
		
		ArrayList <Avatar> lista = new ArrayList();
		

		
	}
}

package factory.exercicioA;

public interface Run {
	public void running ();
}

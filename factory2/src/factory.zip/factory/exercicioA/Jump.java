package factory.exercicioA;

public interface Jump {
	public void jumping ();
}

package factory.exercicioA;

public class RunFast implements Run{
	public void running () {
		System.out.println("Corrida Rapida");
	}
}

package factory.exercicioA;

public class MediumAttack implements Attack{
	public void attacking () {
		System.out.println("Ataque medio");
	}
}

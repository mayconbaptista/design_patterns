package factory.exercicioA;

public class StrongAttack implements Attack{
	public void attacking () {
		System.out.println("Ataque forte");
	}
}

package factory.exercicioA;

public class HighJump implements Jump{
	public void jumping () {
		System.out.println("pulando alto");
	}
}

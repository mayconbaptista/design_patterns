package factory.exercicioA;

public class RunMedium implements Run{
	public void running () {
		System.out.println("Corrida media");
	}
}

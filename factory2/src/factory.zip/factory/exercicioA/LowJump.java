package factory.exercicioA;

public class LowJump implements Jump{
	public void jumping () {
		System.out.println("Pulo Baixo");
	}
}

package factory.exercicioA;

public class WeakAttack implements Attack{
	public void attacking () {
		System.out.println("Ataque fraco");
	}
}

package factory.exercicioA;

public interface Attack {
	public abstract void attacking ();
}

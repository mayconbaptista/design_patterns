package factory.exercicioA;

public class MediumJump implements Jump{
	public void jumping () {
		System.out.println("Pulo medio");
	}
}

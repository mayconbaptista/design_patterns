package factory.exercicioA;

public class RunSlow implements Run{
	public void running () {
		System.out.println("Corrida lenta");
	}
}
